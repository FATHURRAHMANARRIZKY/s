import React from 'react'
import Image from 'next/image'

const Hero = () => {
  return (
    <div className="hero flex flex-col">
        <div className="image">
            <Image src={"/f21-man.png"} className='man absolute right-0 top-17' alt={''} width={636} height={0} />
        </div>
        <div className="text mt-36">
          <h1 className="flex flex-col text-5xl font-extrabold mb-5">One Developer,
      <span>Many Digital Solutions.</span></h1>
      <p className="text-2xl mb-8">The Right Solution for Every Digital Need.</p>
      <button className="px-6 py-2 rounded-lg transition duration-300 w-36 text-base hover:text-black hover:bg-blue-500">
        Get Started
      </button>
        </div>
      
    </div>
  )
}

export default Hero