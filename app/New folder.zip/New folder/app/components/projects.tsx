import React from "react";
import Image from "next/image";

const Project = () => {
  return (
    <div className="projects flex flex-col items-center justify-center">
      <div className="title font-normal">Our Projects</div>
      <div className="cards flex flex-row items-center justify-between">
        <div className="card bg-black shadow-lg rounded-lg flex flex-col w-[280px] h-[360px]">
          <div className="image bg-white rounded-t-lg h-[180px] w-full flex items-center justify-center">
            <Image src={"/logo.png"} alt={""} width={280} height={180} className="rounded-t-lg" />
          </div>
          <div className="project-title">
            <h2 className="text-xl font-medium">project 1</h2>
          </div>
          <div className="project-description">
            <p className="text-base">Description of project 1</p>
            </div>
        </div>
        <div className="card bg-black shadow-lg rounded-lg flex flex-col w-[280px] h-[360px]">
          <div className="image bg-white rounded-t-lg h-[180px] w-full flex items-center justify-center">
            <Image src={"/logo.png"} alt={""} width={280} height={180} className="rounded-t-lg" />
          </div>
          <div className="project-title">
            <h2 className="text-xl font-medium">project 1</h2>
          </div>
          <div className="project-description">
            <p className="text-base">Description of project 1</p>
            </div>
        </div>
        <div className="card bg-black shadow-lg rounded-lg flex flex-col w-[280px] h-[360px]">
          <div className="image bg-white rounded-t-lg h-[180px] w-full flex items-center justify-center">
            <Image src={"/logo.png"} alt={""} width={280} height={180} className="rounded-t-lg" />
          </div>
          <div className="project-title">
            <h2 className="text-xl font-medium">project 1</h2>
          </div>
          <div className="project-description">
            <p className="text-base">Description of project 1</p>
            </div>
        </div>
        <div className="card bg-black shadow-lg rounded-lg flex flex-col w-[280px] h-[360px]">
          <div className="image bg-white rounded-t-lg h-[180px] w-full flex items-center justify-center">
            <Image src={"/logo.png"} alt={""} width={280} height={180} className="rounded-t-lg" />
          </div>
          <div className="project-title">
            <h2 className="text-xl font-medium">project 1</h2>
          </div>
          <div className="project-description">
            <p className="text-base">Description of project 1</p>
            </div>
        </div>
      </div>
    </div>
  );
};

export default Project;