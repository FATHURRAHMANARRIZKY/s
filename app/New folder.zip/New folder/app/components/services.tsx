'use client';

import React, { useState, useEffect } from "react";
import axios from "axios";
import Image from "next/image";

interface Service {
  name: string;
  description: string;
  imageUrl: string;
  minPrice: number;
  maxPrice: number;
}

const Services = () => {
  const [services, setServices] = useState<Service[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const image = "http://localhost:8080";

  useEffect(() => {
    const fetchServices = async () => {
      try {
        const response = await axios.get("http://localhost:8080/services");
        setServices(response.data); // Set response data to the state
        setLoading(false);
      } catch (err) {
        setError("Failed to load services");
        setLoading(false);
      }
    };

    fetchServices();
  }, []);

  if (loading) return <p>Loading...</p>;
  if (error) return <p>{error}</p>;

  return (
    <div className="services flex flex-col items-center justify-center">
      <div className="title font-normal">Our Services</div>
      <div className="cards flex flex-row items-center justify-between">
        {services.map((service, index) => (
          <div key={index} className="card bg-black shadow-lg rounded-lg flex flex-col w-[280px] h-[360px]">
            <div className="image bg-white rounded-t-lg h-[180px] w-full flex items-center justify-center">
            <img
  src={service.imageUrl ? `${image}${service.imageUrl}` : "/logo.png"}
  alt={service.name}
  width={280}
  height={180}
  className="rounded-t-lg"
/>

            </div>
            <div className="service-title">
              <h2 className="text-xl font-medium">{service.name}</h2>
            </div>
            <div className="service-description">
              <p className="text-base">{service.description}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Services;