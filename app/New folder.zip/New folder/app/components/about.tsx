import React from 'react'
import Image from 'next/image'

const About = () => {
  return (
    <div className='about flex flex-row items-center justify-between pt-24'>
      <div className="brand">
        <Image src={"/logo.png"} alt={"F21"} width={400} height={400} />
      </div>

      <div className="text flex flex-col max-w-xl">
        <div className="title text-4xl font-medium mb-4">About F21</div>
        <div className="text-justify mb-4 text-xl">
          F21 is a brand run by a flexible solo developer with diverse digital solutions. From UI/UX design, frontend and backend development, to hosting we provide the right solutions for your digital needs. With strong experience and eagerness to learn, F21 is committed to delivering professional results fast and on point.
        </div>
        <div className="second-about-text text-xl">
          Fast Response, Full Revision, Clean Code, Communicative
        </div>
      </div>
    </div>
  )
}

export default About