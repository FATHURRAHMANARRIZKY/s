import { TbMessages } from "react-icons/tb";

const Chatwidget = () => {
  return (
    <div className="fixed bottom-24 right-24 transition duration-300">
      <div className="flex items-center justify-center h-12 w-12 rounded-full bg-blue-300 text-black hover:bg-blue-700 transition duration-300">
        <TbMessages className="w-6 h-6" />
      </div>
    </div>
  );
};

export default Chatwidget;
