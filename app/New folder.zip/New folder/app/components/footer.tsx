import React from "react";

const Footer = () => {
  return (
    <div className="footer bg-black text-white flex flex-col p-8">
      <div className="top-section flex justify-between flex-wrap">
        <div className="brand-area flex flex-col max-w-70">
          <div className="brand text-3xl font-extrabold">F21</div>
          <div className="subtitle text-xl font-extrabold mt-2 leading-snug flex flex-col">
            One Developer,<span>Many Digital Solutions.</span> 
          </div>
        </div>

        <div className="menu-link flex flex-col items-center mr-36">
          <div className="title font-semibold mb-2">Menu</div>
          <div className="grid grid-cols-2 gap-x-4 gap-y-2">
            <button className="hover:underline">Home</button>
            <button className="hover:underline">Services</button>
            <button className="hover:underline">About</button>
            <button className="hover:underline">Projects</button>
            <button className="hover:underline">Products</button>
            <button className="hover:underline">Contact</button>
          </div>
        </div>
        <div className="social-media flex flex-col gap-2 mr-20 text-center">
          <div className="title font-semibold mb-1">Social Media</div>
          <a
            href="https://www.facebook.com/"
            target="_blank"
            rel="noopener noreferrer"
            className="hover:underline"
          >
            Facebook
          </a>
          <a
            href="https://www.instagram.com/"
            target="_blank"
            rel="noopener noreferrer"
            className="hover:underline"
          >
            Instagram
          </a>
          <a
            href="https://www.linkedin.com/"
            target="_blank"
            rel="noopener noreferrer"
            className="hover:underline"
          >
            LinkedIn
          </a>
          <a
            href="https://twitter.com/"
            target="_blank"
            rel="noopener noreferrer"
            className="hover:underline"
          >
            Twitter
          </a>
        </div>
      </div>
      <hr className="border-gray-700 my-4" />
      <div className="bottom-section text-center text-sm space-y-1 mb-2">
        <div>© 2025 F21.site. All rights reserved.</div>
        <div className="flex justify-center gap-4">
          <div className="privacy-policy hover:underline cursor-pointer">
            Privacy Policy
          </div>
          <div className="terms-of-service hover:underline cursor-pointer">
            Terms of Service
          </div>
        </div>
      </div>
    </div>
  );
};

export default Footer;