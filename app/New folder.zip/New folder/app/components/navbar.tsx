import React from "react";
import Image from "next/image";
import { TbWorld } from "react-icons/tb";
import { FaChevronDown, FaRegUserCircle } from "react-icons/fa";
import { IoMdNotifications } from "react-icons/io";
import Link from "next/link";

const Navbar = () => {
  return (
    <div className="navbar sticky top-0 z-50 flex justify-between items-center">
      <div className="brand">
        <Image src={"/logo.png"} alt={""} width={40} height={40} />
      </div>
      <div className="menu-link flex ml-36 gap-4">
        <button>Home</button>
        <button>About</button>
        <Link href="/products">Products</Link>
        <button>Services</button>
        <button>Projects</button>
        <button>Contact</button>
      </div>
      <div className="user flex gap-4">
        <div className="language">
          <a href="/" className="flex gap-1">
            <TbWorld className="w-[20px] h-[20px]" /> <span>Language</span>
            <FaChevronDown className="w-[20px] h-[20px]" />
          </a>
        </div>
        <div className="notification">
          <IoMdNotifications className="w-[20px] h-[20px]" />
        </div>
        <div className="profile">
          <FaRegUserCircle className="w-[20px] h-[20px]" />
        </div>
      </div>
    </div>
  );
};

export default Navbar;
