import React from 'react'
import Image from 'next/image'
import Link from 'next/link'
import { FaSquareGithub, FaSquareInstagram, FaLinkedin } from "react-icons/fa6";

const Contact = () => {
  return (
    <div className="contact flex justify-center items-center">
      <div className="contact-container bg-white w-[1104px] h-[600px] rounded-3xl flex">
        {/* Kiri */}
        <div className="left-side flex flex-col justify-start w-1/2 p-8">
          <div className="title text-black font-medium text-2xl mb-4">Let's Get In Touch</div>
          <Image src={"/logo.png"} alt={"F21"} width={400} height={400} />
          <div className="icon text-black flex gap-4 mt-8">
            <Link href="/"><FaSquareInstagram className='w-8 h-8 rounded-xl' /></Link>
            <Link href="/"><FaSquareGithub className='w-8 h-8 rounded-xl' /></Link>
            <Link href="/"><FaLinkedin className='w-8 h-8 rounded-xl' /></Link>
          </div>
        </div>
        <div className="contact-side w-[552px] h-full rounded-r-3xl">
            <div className="title m-8 font-medium">Contact Us</div>
            <div className="form flex flex-col gap-5 m-8">
              <input type="text" placeholder='Name' className='rounded-3xl'/>
              <input type="email" placeholder='Email' className='rounded-3xl'/>
              <textarea name="" id="" cols={30} rows={10} placeholder='Message' className='rounded-3xl h-[170px]'></textarea>
              <button className='rounded-3xl p-2 mt-1'>Send</button>
              </div>
        </div>
      </div>
    </div>
  )
}

export default Contact