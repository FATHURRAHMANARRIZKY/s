import Navbar from "./components/navbar";
import "./components/components.css";
import Hero from "./components/hero";
import Chatwidget from "./components/chatwidget";
import About from "./components/about";
import Services from "./components/services";
import Project from "./components/projects";
import Contact from "./components/contactus";
import Footer from "./components/footer";

export default function Home() {
  return (
    <>
      <Navbar />
      <div className="content">
        <Hero />
        <About />
        <Services />
        <Project />
        <Contact />
      </div>

      <Footer />
      <Chatwidget />
    </>
  );
}
