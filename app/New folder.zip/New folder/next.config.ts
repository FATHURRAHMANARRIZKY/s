import type { NextConfig } from "next";

const nextConfig: NextConfig = {
    devIndicators: false,
    images: {
        domains: ['localhost', 'localhost:8080'],
      },
};

export default nextConfig;
